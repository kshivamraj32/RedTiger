from django.http import HttpResponse
from .utils import *

def index(request):
    return HttpResponse("<h1>This will be a list of all albums</h1>")




def detail(request, album_id):
    return HttpResponse("<h2> " + str(get_literary_value((album_id))) + "</h2>")
