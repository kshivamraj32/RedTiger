from django.apps import AppConfig


class RedtigerConfig(AppConfig):
    name = 'redTiger'
