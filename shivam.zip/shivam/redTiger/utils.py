import nltk 
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
from nltk.tokenize import word_tokenize, sent_tokenize
'''
txt = "Sukanya, Rajib and Naba are my good friends. Sukanya is getting married next year. Marriage is a big step in one’s life. It is both exciting and frightening. But friendship is a sacred bond between people. It is a special kind of love between us. Many of you must have tried searching for a friend but never found the right one."
'''


def get_literary_value(txt):
	noun=['NN','NNS','NNP','NNPS']
	verb=['MD','VB','VBD','VBG','VBN','VBP','VBZ']
	adv=['RB','RBR','RBS','WRB']
	adj=['JJ','JJR','JJS',]
	literary_value=0
	tokenized = word_tokenize(txt) 
	for i in tokenized: 
	  wordsList = nltk.word_tokenize(i) 
	  tagged = nltk.pos_tag(wordsList)
	  for w,p in tagged:
	    if p in noun:
	      literary_value=literary_value+7
	      #print(w," noun")
	    if p in verb:
	      literary_value=literary_value+14
	      #print(w," verb")
	    if p in adv:
	      #print(w," adv")
	      literary_value=literary_value+21      
	    if p in adj:
	      literary_value=literary_value+2
	      #print(w," adj")
	return literary_value

